-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2020 at 05:43 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `delivery`
--

-- --------------------------------------------------------

--
-- Table structure for table `emp_data`
--

CREATE TABLE `emp_data` (
  `id` varchar(70) NOT NULL,
  `name` varchar(70) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_data`
--

INSERT INTO `emp_data` (`id`, `name`, `email`, `password`, `phone`, `address`) VALUES
('', '', '', '', '', ''),
('', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `markstatus`
--

CREATE TABLE `markstatus` (
  `phone` varchar(18) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `markstatus`
--

INSERT INTO `markstatus` (`phone`, `status`) VALUES
('2089289', 'delivered');

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `phonenumber` varchar(60) NOT NULL,
  `item1` varchar(60) NOT NULL,
  `quantity1` varchar(60) NOT NULL,
  `item2` varchar(60) NOT NULL,
  `quantity2` varchar(60) NOT NULL,
  `item3` varchar(60) NOT NULL,
  `quantity3` varchar(60) NOT NULL,
  `item4` varchar(60) NOT NULL,
  `quantity4` varchar(60) NOT NULL,
  `item5` varchar(60) NOT NULL,
  `quantity5` varchar(60) NOT NULL,
  `item6` varchar(60) NOT NULL,
  `quantity6` varchar(60) NOT NULL,
  `item7` varchar(60) NOT NULL,
  `quantity7` varchar(60) NOT NULL,
  `item8` varchar(60) NOT NULL,
  `quantity8` varchar(60) NOT NULL,
  `item9` varchar(60) NOT NULL,
  `quantity9` varchar(60) NOT NULL,
  `item10` varchar(60) NOT NULL,
  `quantity10` varchar(50) NOT NULL,
  `total` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`firstname`, `lastname`, `phonenumber`, `item1`, `quantity1`, `item2`, `quantity2`, `item3`, `quantity3`, `item4`, `quantity4`, `item5`, `quantity5`, `item6`, `quantity6`, `item7`, `quantity7`, `item8`, `quantity8`, `item9`, `quantity9`, `item10`, `quantity10`, `total`, `address`) VALUES
('anowaR', 'hossen', '09328', 'beef', '1', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', '170', ''),
('Afsana', 'Mimi', '093282e4', 'beef', '1', 'egg', '2', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', '230', ''),
('Afsana', 'Mimi', '01991074972', 'biriani', '2', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', '300', 'sanirakhra'),
('mimi', 'sadia', '018982', 'biriani', '1', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', '150', 'vghvggf'),
('sadia', 'ahmed', '981989128', 'chicken', '1', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', '90', 'vh2vbv2'),
('Afsana', 'Mimi', '989298', 'chicken', '2', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', 'Null', '0', '180', '1`r15`65`1');

-- --------------------------------------------------------

--
-- Table structure for table `select_deliveryman`
--

CREATE TABLE `select_deliveryman` (
  `id` varchar(60) NOT NULL,
  `oder` varchar(60) NOT NULL,
  `addr` varchar(70) NOT NULL,
  `num` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `select_deliveryman`
--

INSERT INTO `select_deliveryman` (`id`, `oder`, `addr`, `num`) VALUES
('45', '01', ' 09328 ', ''),
('12', '7', ' 01991074972 ', 'sanirakhra'),
('9', '1', 'sanirakhra', ' 01991074972 '),
('41', '67', ' 989298 ', '1`r15`65`1'),
('99', '3', ' 09328 ', ''),
('99', '3', ' 09328 ', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(60) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(30) NOT NULL,
  `confirm_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`first_name`, `last_name`, `email`, `phone`, `password`, `confirm_password`) VALUES
('abid', 'hamid', 'hamid@gmail.com', '1819728786', 'hamid', 'hamid'),
('abid', 'hamid', 'hamid@gmail.com', '1819728786', 'hamid', 'hamid'),
('afsana', 'mimi', 'mimi@gmail.com', '2089289', 'njsdn', 'hsjh'),
('vnnf', 'dsbfsdnbf', 'dbsbnsdb', '1898', 'mimi', 'mimi'),
('hamid', 'baccha', 'baccha@gmail.com', '1898', 'mimi', 'mimi'),
('sadia', 'ahmed', 'sadia@gmail.com', '1898564', '111', '111'),
('afsana', 'mimi', 'ajhsajah', '01898', '1111', '1111'),
('sana', 'mimi', 'ahgahjgah', '017868', 'mimi', 'mimi'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('hamid', 'arif', 'sanamimi@620.com', '01898222', '9999', '9999'),
('titu', 'mitu', 'sbsb', '01898', 'mimi', 'mimi'),
('titu', 'mitu', 'sbsb', '01898', 'mimi', 'mimi'),
('afsana', 'mimi', 'abnaba', '01898', 'mimi', 'mimi'),
('zarin', 'akter', 'abnaba', '018982', 'mimi', 'mimi'),
('rina', 'akter', 'zghag', '01898', 'mimi', 'mimi'),
('giraf', 'bvba', 'aza', '01898', '1111', '1111'),
('voroasha', 'bnabn', 'ambaqn', '01898', '1111', '1111'),
('gaga', 'bnabn', 'ambaqn', '01898', '1111', '1111'),
('fiza', 'vbv', '', '01898', '1111', '1111'),
('basit', 'ghgh', 'bnbn', '01898', '1111', '1111'),
('anjum', 'ara', 'bnbn', '01898', '1111', '1111'),
('MUNIRa', 'CDD', 'FF', '01898', '1111', '1111'),
('yale', 'vbv', 'ax', '01898', '1111', '1111'),
('ANOWAR', 'hossain', 'vbvgbv', '01898', '1111', '1111'),
('Anika', 'ahmed', 'anika@gmail.com', '01819724178', '2222', '2222'),
('Anika', 'ahmed', 'anika@gmail.com', '01819724178', '2222', '2222'),
('Anika', 'ahmed', 'anika@gmail.com', '01819724178', '2222', '2222');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
